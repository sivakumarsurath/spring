package com.cg.user.exception;

public class UserException extends Exception {

	public UserException() {
		super();
			}

	public UserException(String message) {
		super(message);
	}
	

}
