package com.cg.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.user.bean.UserManagement;
import com.cg.user.exception.UserException;
import com.cg.user.service.UserService;
@CrossOrigin(origins="http://localhost:8500")
@RestController
public class UserController {

	@Autowired
	private UserService userService;
	@GetMapping("/")
	public List<UserManagement> getAllUsers() throws UserException {
		// TODO Auto-generated method stub
		return userService.getAllUsers();
	}
	
	@PostMapping("/add")
	UserManagement addUser(@RequestBody UserManagement userManagement) throws UserException{
		return userService.addUser(userManagement);
	}
	
	@PutMapping("/edit/{id}")
	public List<UserManagement> updateUser(@PathVariable int id,@RequestBody UserManagement userManagement) throws UserException{
		System.out.println(id);
		return userService.updateUser(id,userManagement);
	}
	
	@GetMapping("/users/{id}")
	public UserManagement getUserById(@PathVariable int id) throws UserException{
		return userService.getUserById(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public List<UserManagement> deleteUser(@PathVariable int id) throws UserException{
		return userService.deleteUser(id);
		
	}
	
	@ExceptionHandler(UserException.class)
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
	
  
    }
   