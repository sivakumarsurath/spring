package com.cg.course.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/***
 * 
 * @author ssurath
 *
 */

import com.cg.course.dao.CourseRepository;
import com.cg.course.dto.Course;
import com.cg.course.exception.CourseException;


@Service
public class CourseServiceImpl implements CourseService {
	
	@Autowired
	private CourseRepository courseDao;

	@Override
	public List<Course> addCourse(Course course) throws CourseException {
		courseDao.save(course);
		return getAllCourses();
	}

	@Override
	public List<Course> getAllCourses() throws CourseException {

		try {
			return courseDao.findAll();
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> updateCourse(String id, Course course) throws CourseException {
		if(courseDao.existsById(course.getCourseId())) {
			courseDao.save(course);
			return getAllCourses();
		}else {
			throw new CourseException("Invalid Course, cannot be  updated");
	}

	}

	@Override
	public List<Course> deleteCourse(String id) throws CourseException {
if(courseDao.existsById(id)) {
			
	courseDao.deleteById(id);
			return getAllCourses();
		}else {
			throw new CourseException("cannot delete. Course with Id "+id+" does not exist");
		}
	}

	@Override
	public Course getCourseById(String id) throws CourseException {
		try {
			
			Optional<Course> data=courseDao.findById(id);
			if(data.isPresent()) {
				return data.get();
			}else {
				throw new CourseException("Employee with Id "+id+" does not exist");
			}
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> getCourseByMode(String mode) throws CourseException {
		
		return courseDao.getCourseByMode(mode);
	}

}