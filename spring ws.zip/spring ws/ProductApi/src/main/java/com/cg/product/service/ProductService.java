package com.cg.product.service;

import java.util.List;
import com.cg.product.dto.Product;
import com.cg.product.exception.ProductException;

public interface ProductService {
	List<Product> addProduct(Product product) throws ProductException;
	List<Product> updateProduct(int id,Product product) throws ProductException;
	List<Product>  getAllProducts() throws ProductException;
	List<Product> productByCategory(String catName) throws ProductException;
	List<Product>  deleteProduct(int id) throws ProductException;
}
