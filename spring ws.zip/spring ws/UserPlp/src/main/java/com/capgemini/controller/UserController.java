package com.capgemini.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bean.UserManagement;
import com.capgemini.exception.UserException;
import com.capgemini.service.UserService;

@RestController
public class UserController {
@Autowired
UserService userService;
@GetMapping("/users")
public List<UserManagement> getAllUsers() throws UserException{
	return userService.getAllUsers();
	
}
@PostMapping("/addusers")
public UserManagement addUser(@RequestBody UserManagement userManagement) throws UserException{
	return userService.addUser(userManagement);
	
}
@GetMapping("/users/{id}")
public UserManagement getUserById(@PathVariable int id) throws UserException {
	return userService.getUserById(id);
}
@PutMapping("/users/{id}")
public List<UserManagement> updateUser(@RequestBody UserManagement userManagement,@PathVariable int id) throws UserException{
	return userService.updateUser(id,userManagement);
}
@DeleteMapping("/users/{id}")
public List<UserManagement> deleteUser(@PathVariable int id) throws UserException{
	return userService.deleteUser(id);
}
}
