package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;

@Entity
public class UserManagement {
	@javax.persistence.Id
	@SequenceGenerator(name = "acc", sequenceName = "acc",initialValue=5,allocationSize = 2)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "acc")
	private int Id;
	@SequenceGenerator(name = "acc", sequenceName = "acc",initialValue=1,allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "acc")
	@Column(name="ind")
	private int Index;
	private String fullName;
	private String email;
	private int password;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getPassword() {
		return password;
	}
	public void setPassword(int password) {
		this.password = password;
	}}