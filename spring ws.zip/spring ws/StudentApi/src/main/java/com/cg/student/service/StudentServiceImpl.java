package com.cg.student.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.student.dao.StudentRepository;
import com.cg.student.dto.Student;
import com.cg.student.exception.StudentException;
@Service
public class StudentServiceImpl implements StudentService {
@Autowired
	private StudentRepository studentDao;

@Override
public List<Student> addStudent(Student student) throws StudentException {
	studentDao.save(student);
	return getAllStudents();
}

@Override
public List<Student> getAllStudents() throws StudentException {

	try {
		return studentDao.findAll();
	} catch (Exception e) {
		throw new StudentException(e.getMessage());
	}
}

@Override
public List<Student> updateStudent(int id, Student student) throws StudentException {
	if(studentDao.existsById(student.getId())) {
		studentDao.save(student);
		return getAllStudents();
	}else {
		throw new StudentException("Invalid Student, cannot be  updated");
}

}

@Override
public List<Student> deleteStudent(int id) throws StudentException {
	if(studentDao.existsById(id)) {
		
		studentDao.deleteById(id);
				return getAllStudents();
			}else {
				throw new StudentException("cannot delete. Student with Id "+id+" does not exist");
			}
}

@Override
public List<Student> getStudentByStream(String stream) throws StudentException {
	return studentDao.getStudentByStream(stream);
}	

}
