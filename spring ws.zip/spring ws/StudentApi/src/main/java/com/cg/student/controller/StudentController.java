package com.cg.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.student.dto.Student;
import com.cg.student.exception.StudentException;
import com.cg.student.service.StudentService;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	private StudentService studentService;
	@PostMapping("/students")
	public List<Student> addStudent(@RequestBody Student student) throws StudentException{
		return studentService.addStudent(student);
		
	}
	@GetMapping("/students")
	public List<Student> getAllStudents() throws StudentException{
		return studentService.getAllStudents();
		
	}
	@PutMapping("/students/{id}")
	public List<Student> updateStudent(@RequestBody Student student,@PathVariable int id) throws StudentException{
		return studentService.updateStudent(id,student);
	}
	@DeleteMapping("/students/{id}")
	public List<Student> deleteStudent(@PathVariable int id) throws StudentException{
		return studentService.deleteStudent(id);
	}
	@GetMapping("/students/{stream}")
	public List<Student> getStudentByStream(@RequestParam String stream) throws StudentException {
		return studentService.getStudentByStream(stream);
	}
}
