package com.cg.student.service;

import java.util.List;

import com.cg.student.dto.Student;
import com.cg.student.exception.StudentException;

public interface StudentService {

	List<Student> addStudent(Student student) throws StudentException;
	List<Student> getAllStudents() throws StudentException;
	List<Student> updateStudent(int id, Student student)throws StudentException;
	List<Student> deleteStudent(int id)throws StudentException;
	List<Student> getStudentByStream(String stream)throws StudentException;
	
}
