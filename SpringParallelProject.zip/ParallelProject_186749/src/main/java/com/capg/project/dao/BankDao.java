package com.capg.project.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capg.project.bean.Account;

@Repository
	public interface BankDao extends JpaRepository<Account, Integer>{
}
