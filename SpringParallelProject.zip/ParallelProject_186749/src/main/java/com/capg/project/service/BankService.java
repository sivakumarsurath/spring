package com.capg.project.service;

import java.util.List;

import com.capg.project.bean.Account;
import com.capg.project.bean.Transaction;

public interface BankService {
	public void createAccount(Account account);
	public boolean validateAccount(int accountNumber);
	public List<Account> showAllAccounts();
	public Account getAccountDetails(int accountNumber);
	public Account showBalance(int accountNumber);
	public Account depositAmount(int accountNumber, Account account);
	public Account withdrawAmount(int accountNumber, Account account);
	public Account fundTransfer(int senderAccountNumber, int recieverAccountNumber, Account account);
	public List<Transaction> getTransactionsByAccountNumber(int accountNumber);

}
