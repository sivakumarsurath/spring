package com.capg.project.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.project.bean.Account;
import com.capg.project.bean.Transaction;
import com.capg.project.service.BankService;

@CrossOrigin(origins="http://localhost:4200")
//@CrossOrigin(origins = "*",allowedHeaders = "*", methods = { RequestMethod.GET,RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT})
@RestController
public class BankController {
	@Autowired
	BankService bankService;
	
	@PostMapping
	public void createAccount(@RequestBody Account account) {
		bankService.createAccount(account);
	}
	
	@GetMapping
	public List<Account> showAccounts(){
		return bankService.showAllAccounts();
	}
	
	@GetMapping("/validate/{accountNumber}")
	public boolean depositAmount(@PathVariable("accountNumber") int accountNumber){
		return bankService.validateAccount(accountNumber);
	}
		
	@GetMapping("/{accountNumber}")
	public Account getAccount(@PathVariable("accountNumber") int accountNumber){
		return bankService.getAccountDetails(accountNumber);
	}
	@GetMapping("/balance/{accountNumber}")
	public Account showAccountBalance(@PathVariable("accountNumber") int accountNumber){
		return bankService.showBalance(accountNumber);
	}
	
	@PutMapping("/deposit/{accountNumber}")
	public Account depositAmount(@PathVariable("accountNumber") int accountNumber, @RequestBody Account account){
		return bankService.depositAmount(accountNumber,account);
	}
	
	@PutMapping("/withdraw/{accountNumber}")
	public Account withdrawAmount(@PathVariable("accountNumber") int accountNumber, @RequestBody Account account){
		return bankService.withdrawAmount(accountNumber,account);
	}
	
	@PutMapping("/transfer/{senderAccountNumber}/{recieverAccountNumber}")
	public Account fundTransfer(@PathVariable("senderAccountNumber") int senderAccountNumber, @PathVariable("recieverAccountNumber") int recieverAccountNumber, @RequestBody Account account){
		return bankService.fundTransfer(senderAccountNumber,recieverAccountNumber,account);
	}
	
	@GetMapping("/transactions/{accountNumber}")
    public List<Transaction> getTransactionsByAccountNumber(@PathVariable("accountNumber") int accountNumber) {
        return bankService.getTransactionsByAccountNumber(accountNumber);
      
    }
 
	
}
