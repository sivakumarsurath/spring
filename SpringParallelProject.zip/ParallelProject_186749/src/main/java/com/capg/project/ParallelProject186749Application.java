package com.capg.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParallelProject186749Application {

	public static void main(String[] args) {
		SpringApplication.run(ParallelProject186749Application.class, args);
	}

}
